import { useState, useEffect, useRef, ChangeEvent, FormEvent } from "react";
import { 
  Mic, 
  Square, 
  Trash2, 
  FileAudio, 
  Calendar as CalendarIcon, 
  FileText, 
  ChevronLeft, 
  ChevronRight, 
  Search, 
  Sparkles, 
  Clipboard, 
  Check, 
  Plus, 
  User, 
  Building2, 
  Clock, 
  Edit3, 
  ChevronDown, 
  ChevronUp, 
  Share2, 
  Settings,
  Upload,
  Pause,
  Play
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { NegotiationRecord, VisitEvent, TranscribeResponse } from "./types";

// Seed data to make the initial experience rich and functional
const SEED_RECORDS: NegotiationRecord[] = [
  {
    id: "seed-1",
    date: "2026-06-10",
    userName: "田中 健太",
    clientName: "株式会社テックリード (山田部長)",
    transcript: "本日は、新システム導入のタイムラインについて打ち合わせを行いました。先方からはセキュリティ認証の取得状況や、要件定義の開始時期について質問がありました。開発工程を約3ヶ月と見込み、来月半ばにキックオフを行うことで基本的に合意いたしました。予算面については次回、詳細見積もりを提出します。",
    summaryPoints: [
      "新システム導入のキックオフを7月中旬に行うことで基本合意",
      "開発期間は約3ヶ月の想定，次回詳細見積もりを提出",
      "セキュリティ要件（ISMS要件）について仕様確認の要望あり"
    ],
    notes: "非常に前向きな商談。次回の詳細見積もりをいかに早く出せるかが鍵。",
    createdAt: new Date("2026-06-10T10:00:00.000Z").toISOString()
  },
  {
    id: "seed-2",
    date: "2026-06-11",
    userName: "田中 健太",
    clientName: "グローバルロジスティクス合同会社 (佐藤社長)",
    transcript: "物流配送ルート最適化ツールの試験導入についての商談。現在の配送効率に難があり、弊社のAIルート最適化モジュールの試験運用のデモを行いました。効果測定として、デリバリーコストが10%削減されるか検証したいとのこと。デモの精度に満足いただき、本日より1ヶ月間の無料トライアルをスタートします。",
    summaryPoints: [
      "AIルート最適化ツールの試験運用（デモ）を実施し、好感触",
      "本日（6月11日）より1ヶ月品質の無料トライアルを開始",
      "目標は配送デリバリーコストの10%削減検証"
    ],
    notes: "トライアルの進捗フォローを週次で行う予定。社長が非常にITに熱心。",
    createdAt: new Date("2026-06-11T09:30:00.000Z").toISOString()
  }
];

const SEED_EVENTS: VisitEvent[] = [
  {
    id: "event-1",
    date: "2026-06-15",
    title: "フォローアップ訪問",
    clientName: "株式会社テックリード",
    notes: "見積書持参および要件ヒアリング"
  },
  {
    id: "event-2",
    date: "2026-06-18",
    title: "新規製品デモ提案",
    clientName: "サクラソリューションズ",
    notes: "オンラインでの一次商談"
  }
];

export default function App() {
  // --- Persistent States from LocalStorage ---
  const [records, setRecords] = useState<NegotiationRecord[]>(() => {
    const saved = localStorage.getItem("sales_negotiations_records");
    return saved ? JSON.parse(saved) : SEED_RECORDS;
  });

  const [events, setEvents] = useState<VisitEvent[]>(() => {
    const saved = localStorage.getItem("sales_negotiations_events");
    return saved ? JSON.parse(saved) : SEED_EVENTS;
  });

  // Save states to localStorage
  useEffect(() => {
    localStorage.setItem("sales_negotiations_records", JSON.stringify(records));
  }, [records]);

  useEffect(() => {
    localStorage.setItem("sales_negotiations_events", JSON.stringify(events));
  }, [events]);

  // --- Active View States ---
  const [activeTab, setActiveTab] = useState<"memo" | "calendar" | "list">("memo");
  
  // --- Audio Recording States ---
  const [isRecording, setIsRecording] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [realtimeTranscript, setRealtimeTranscript] = useState("");
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [engine, setEngine] = useState<"gemini" | "whisper">("gemini");
  
  // --- Transcription & Form Review Sates ---
  const [isProcessing, setIsProcessing] = useState(false);
  const [systemMessage, setSystemMessage] = useState<string>("");
  const [errorText, setErrorText] = useState<string | null>(null);
  
  // Draft Form State for newly analyzed items
  const [draftRecord, setDraftRecord] = useState<{
    date: string;
    userName: string;
    clientName: string;
    transcript: string;
    summaryPoints: string[];
    notes: string;
  } | null>(null);

  // Edit State for existing records
  const [editingRecordId, setEditingRecordId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [confirmingDeleteId, setConfirmingDeleteId] = useState<string | null>(null);

  // --- Calendar Hook States ---
  const [currentDate, setCurrentDate] = useState(() => new Date(2026, 5, 11)); // Controlled Initial Date: June 2026
  const [selectedCalendarDate, setSelectedCalendarDate] = useState<string>("2026-06-11");
  const [showAddEventModal, setShowAddEventModal] = useState(false);
  const [newEvent, setNewEvent] = useState({
    title: "",
    clientName: "",
    date: "2026-06-11",
    notes: ""
  });

  // --- Search / List Filter States ---
  const [searchQuery, setSearchQuery] = useState("");
  const [expandedRecordId, setExpandedRecordId] = useState<string | null>(null);

  // Audio Recording References
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunkDataRef = useRef<Blob[]>([]);
  const timerIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const recognitionRef = useRef<any>(null);
  const isRecordingRef = useRef(false);
  const isPausedRef = useRef(false);
  const isRecognitionActiveRef = useRef(false);

  // Web Audio API refs for visualizer
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animationRefId = useRef<number | null>(null);
  const barsRef = useRef<(HTMLDivElement | null)[]>([]);
  const lastValuesRef = useRef<number[]>([]);
  const liveTranscriptScrollRef = useRef<HTMLDivElement | null>(null);

  // Auto-scroll real-time transcript container to the bottom
  useEffect(() => {
    if (liveTranscriptScrollRef.current) {
      liveTranscriptScrollRef.current.scrollTop = liveTranscriptScrollRef.current.scrollHeight;
    }
  }, [realtimeTranscript]);

  const cleanupAudioVisualizer = () => {
    if (animationRefId.current) {
      cancelAnimationFrame(animationRefId.current);
      animationRefId.current = null;
    }
    if (audioContextRef.current) {
      if (audioContextRef.current.state !== "closed") {
        audioContextRef.current.close().catch(e => console.error(e));
      }
      audioContextRef.current = null;
    }
    analyserRef.current = null;
  };

  // --- Microphone Recorder Functions ---
  const startRecording = async () => {
    try {
      setErrorText(null);
      setAudioUrl(null);
      setAudioBlob(null);
      setDraftRecord(null);
      setRealtimeTranscript("");
      setIsPaused(false);
      isPausedRef.current = false;
      chunkDataRef.current = [];

      // Ask for microphone permissions
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      // Select compatible iOS codec
      const mimeTypes = ["audio/webm", "audio/mp4", "audio/wav", "audio/aac"];
      let supportedType = "";
      
      try {
        supportedType = mimeTypes.find(type => MediaRecorder.isTypeSupported(type)) || "";
      } catch (e) {
        console.warn("MediaRecorder.isTypeSupported is not available:", e);
      }
      
      let recorder: MediaRecorder;
      try {
        const options: MediaRecorderOptions = {};
        if (supportedType) {
          options.mimeType = supportedType;
        }
        recorder = new MediaRecorder(stream, options);
      } catch (mimeErr) {
        console.warn("Failed to initialize MediaRecorder with preferred mimeType, trying default constructor:", mimeErr);
        try {
          recorder = new MediaRecorder(stream);
          supportedType = recorder.mimeType || "";
        } catch (fallbackErr: any) {
          console.error("Critical: MediaRecorder initialization completely failed:", fallbackErr);
          throw new Error("録音機能(MediaRecorder)の初期化に失敗しました。お使いのブラウザが録音に対応しているかご確認ください。");
        }
      }

      mediaRecorderRef.current = recorder;

      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) {
          chunkDataRef.current.push(e.data);
        }
      };

      recorder.onstop = () => {
        const fullBlob = new Blob(chunkDataRef.current, { type: supportedType || "audio/mp4" });
        setAudioBlob(fullBlob);
        setAudioUrl(URL.createObjectURL(fullBlob));
        
        // Stop all audio tracks to release microphone
        stream.getTracks().forEach(track => track.stop());

        // Stop voice recognition
        isRecognitionActiveRef.current = false;
        if (recognitionRef.current) {
          try {
            recognitionRef.current.stop();
          } catch (recStopErr) {
            console.warn("Error stopping voice recognition in recorder.onstop:", recStopErr);
          }
        }

        // Automatically trigger AI transcription and summarization!
        requestTranscriptionAndSummary(fullBlob);
      };

      // Set up Audio Visualizer
      try {
        const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
        const source = audioContext.createMediaStreamSource(stream);
        const analyser = audioContext.createAnalyser();
        analyser.fftSize = 64; // 32 frequency bins
        analyser.smoothingTimeConstant = 0.4; // Smooth internally
        source.connect(analyser);

        audioContextRef.current = audioContext;
        analyserRef.current = analyser;

        // Initialize smoothing physics array
        lastValuesRef.current = Array(16).fill(0.08);

        // Start animation frame
        const updateWaveform = () => {
          if (!analyserRef.current) return;

          // If paused, settle waves at flat level and skip reading frequency data
          if (isPausedRef.current) {
            for (let i = 0; i < 16; i++) {
              const barElement = barsRef.current[i];
              if (barElement) {
                barElement.style.transform = "scaleY(0.08)";
              }
            }
            animationRefId.current = requestAnimationFrame(updateWaveform);
            return;
          }

          const currentAnalyser = analyserRef.current;
          const bufferLength = currentAnalyser.frequencyBinCount; // 32
          const dataArray = new Uint8Array(bufferLength);
          currentAnalyser.getByteFrequencyData(dataArray);

          for (let i = 0; i < 16; i++) {
            const barElement = barsRef.current[i];
            if (barElement) {
              // Focus on typical conversational vocal frequency ranges
              const dataIdx = Math.min(Math.floor(i * 1.2), bufferLength - 1);
              const rawVal = dataArray[dataIdx] || 0;
              
              let targetVal = rawVal / 255;
              // Visual boost to look more responsive
              targetVal = Math.min(1.0, Math.max(0.08, targetVal * 1.6));

              // Smooth transition physics (Lerp)
              let prevVal = lastValuesRef.current[i] ?? 0.08;
              const factor = targetVal > prevVal ? 0.38 : 0.12; // Snap up quickly, fall down slowly
              const nextVal = prevVal + (targetVal - prevVal) * factor;
              
              lastValuesRef.current[i] = nextVal;
              barElement.style.transform = `scaleY(${nextVal})`;
            }
          }
          animationRefId.current = requestAnimationFrame(updateWaveform);
        };

        // Start loop
        animationRefId.current = requestAnimationFrame(updateWaveform);

      } catch (audioErr) {
        console.warn("Could not satisfy web audio setup for visualization:", audioErr);
      }

      recorder.start(250); // Get chunks every 250ms
      setIsRecording(true);
      isRecordingRef.current = true;
      setRecordingDuration(0);

      // Start duration counter timer
      timerIntervalRef.current = setInterval(() => {
        setRecordingDuration(prev => prev + 1);
      }, 1000);

      // Set up real-time Web Speech API Transcription
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        const recognition = new SpeechRecognition();
        recognition.continuous = true;
        recognition.interimResults = true;
        recognition.lang = "ja-JP";

        recognition.onresult = (event: any) => {
          let full = "";
          for (let i = 0; i < event.results.length; ++i) {
            full += event.results[i][0].transcript;
          }
          setRealtimeTranscript(full);
        };

        recognition.onerror = (recErr: any) => {
          console.warn("SpeechRecognition error:", recErr);
        };

        recognition.onend = () => {
          // If we are still actively recording and not paused, auto-restart the speech listener
          if (isRecordingRef.current && !isPausedRef.current && isRecognitionActiveRef.current) {
            try {
              recognition.start();
            } catch (restartErr) {
              console.warn("Could not restart SpeechRecognition:", restartErr);
            }
          }
        };

        recognitionRef.current = recognition;
        try {
          isRecognitionActiveRef.current = true;
          recognition.start();
        } catch (startRecErr) {
          console.warn("Could not start SpeechRecognition:", startRecErr);
        }
      }

    } catch (err) {
      console.error("Mic access denied or error:", err);
      setErrorText("マイクへアクセスできません。iPhoneの設定などでマイク権限を許可してください。");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      setIsRecording(false);
      isRecordingRef.current = false;
      setIsPaused(false);
      isPausedRef.current = false;

      // Stop voice recognition
      isRecognitionActiveRef.current = false;
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (recStopErr) {
          console.warn("Error stopping voice recognition in stopRecording:", recStopErr);
        }
      }

      mediaRecorderRef.current.stop();
      if (timerIntervalRef.current) {
        clearInterval(timerIntervalRef.current);
      }
      cleanupAudioVisualizer();
    }
  };

  const cancelRecording = () => {
    setIsRecording(false);
    isRecordingRef.current = false;
    setIsPaused(false);
    isPausedRef.current = false;

    // Stop voice recognition
    isRecognitionActiveRef.current = false;
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (recStopErr) {
        console.warn("Error stopping voice recognition in cancelRecording:", recStopErr);
      }
    }

    if (mediaRecorderRef.current) {
      try {
        mediaRecorderRef.current.stop();
      } catch (stopMediaErr) {
        console.warn("Error stopping MediaRecorder on cancel:", stopMediaErr);
      }
    }
    if (timerIntervalRef.current) {
      clearInterval(timerIntervalRef.current);
    }
    cleanupAudioVisualizer();
    setAudioBlob(null);
    setAudioUrl(null);
    setRecordingDuration(0);
    setRealtimeTranscript("");
  };

  const pauseRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === "recording") {
      try {
        mediaRecorderRef.current.pause();
      } catch (err) {
        console.warn("Failed to pause mediaRecorder:", err);
      }
      setIsPaused(true);
      isPausedRef.current = true;
      if (timerIntervalRef.current) {
        clearInterval(timerIntervalRef.current);
        timerIntervalRef.current = null;
      }
      // Temporarily halt Speech Recognition as well
      if (recognitionRef.current) {
        try {
          isRecognitionActiveRef.current = false;
          recognitionRef.current.stop();
        } catch (recStopErr) {
          console.warn("Could not stop recognition on pause:", recStopErr);
        }
      }
    }
  };

  const resumeRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === "paused") {
      try {
        mediaRecorderRef.current.resume();
      } catch (err) {
        console.warn("Failed to resume mediaRecorder:", err);
      }
      setIsPaused(false);
      isPausedRef.current = false;

      // Resume timer
      if (!timerIntervalRef.current) {
        timerIntervalRef.current = setInterval(() => {
          setRecordingDuration(prev => prev + 1);
        }, 1000);
      }

      // Resume Speech Recognition
      if (recognitionRef.current && !isRecognitionActiveRef.current) {
        try {
          isRecognitionActiveRef.current = true;
          recognitionRef.current.start();
        } catch (recStartErr) {
          console.warn("Could not start recognition on resume:", recStartErr);
        }
      }
    }
  };

  // --- Manual iPhone File Picker Selection ---
  const handleAudioFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setDraftRecord(null);
      setErrorText(null);
      setAudioBlob(file);
      setAudioUrl(URL.createObjectURL(file));
      setSystemMessage(`ファイル「${file.name}」を読み込みました。`);
      requestTranscriptionAndSummary(file);
    }
  };

  // Helper: Convert File/Chunk to Base64 String
  const convertBlobToBase64 = (blob: Blob): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        const base64Data = base64String.split(",")[1];
        resolve(base64Data);
      };
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  };

  // --- Call API for Transcription and Summarization ---
  const requestTranscriptionAndSummary = async (blobOverride?: Blob) => {
    const targetBlob = blobOverride || audioBlob;
    if (!targetBlob) {
      setErrorText("音声ファイルまたは録音データが見つかりません。先に録音するかファイルを選択してください。");
      return;
    }

    setIsProcessing(true);
    setErrorText(null);
    setSystemMessage("音声データを変換中...");

    try {
      const base64Audio = await convertBlobToBase64(targetBlob);
      const mimeType = targetBlob.type || "audio/mp4";

      setSystemMessage("AI解析をリクエスト中 (文字起こし & 要素抽出)...");

      const response = await fetch("/api/transcribe-summarize", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          audio: base64Audio,
          mimeType: mimeType,
          method: engine, // 'gemini' or 'whisper'
        }),
      });

      const responseText = await response.text();
      let resData: any = null;
      try {
        if (responseText) {
          resData = JSON.parse(responseText);
        }
      } catch (jsonErr) {
        console.error("JSON parse error on server response:", jsonErr, responseText);
        throw new Error(`サーバーから予期しない形式の応答がありました（ステータス: ${response.status}）。詳細: ${responseText.slice(0, 150) || "空の応答"}`);
      }

      if (!response.ok) {
        throw new Error(resData?.error || `サーバーエラーが発生しました（ステータス: ${response.status}）`);
      }

      if (!resData) {
        throw new Error("サーバーから空の応答が返されました。");
      }

      // Format Date String for draft (Defaults to today in YYYY-MM-DD)
      const jstDate = new Date().toISOString().split("T")[0];

      setDraftRecord({
        date: jstDate,
        userName: resData.userName || "営業担当者",
        clientName: resData.clientName || "確認中の顧客",
        transcript: resData.transcription,
        summaryPoints: resData.summaryPoints && resData.summaryPoints.length > 0
          ? resData.summaryPoints 
          : ["商談実施。具体的な要約を生成できませんでした。"],
        notes: ""
      });

      setSystemMessage("解析完了！以下の項目を確認・変更の上、保存してください。");
    } catch (err) {
      console.error(err);
      setErrorText(err instanceof Error ? err.message : "サーバー処理中に不明なエラーが発生しました。");
    } finally {
      setIsProcessing(false);
    }
  };

  // --- Draft Form Interaction ---
  const saveDraftToRecords = () => {
    if (!draftRecord) return;

    const newRecord: NegotiationRecord = {
      id: "rec-" + Date.now(),
      date: draftRecord.date,
      userName: "", // 営業担当者名は削除
      clientName: draftRecord.clientName,
      transcript: draftRecord.transcript,
      summaryPoints: draftRecord.summaryPoints.filter(p => p.trim() !== ""),
      notes: draftRecord.notes,
      createdAt: new Date().toISOString()
    };

    setRecords(prev => [newRecord, ...prev]);
    
    // Auto-create a visual calendar event as well for simple record tracking!
    const companionEvent: VisitEvent = {
      id: "evt-" + Date.now(),
      date: draftRecord.date,
      title: "【音声記録】",
      clientName: draftRecord.clientName,
      notes: draftRecord.summaryPoints[0] || "音声議事録"
    };
    setEvents(prev => [...prev, companionEvent]);

    // Reset draft
    setDraftRecord(null);
    setAudioUrl(null);
    setAudioBlob(null);
    
    // Switch to history/list tab
    setActiveTab("list");
  };

  // Delete negotiation entry
  const deleteRecord = (id: string) => {
    setRecords(prev => prev.filter(r => r.id !== id));
    setConfirmingDeleteId(null);
  };

  // Copy structured layout for Business Messaging App
  const copyToClipboard = (record: NegotiationRecord) => {
    const textToCopy = `【議事録】
記録日: ${record.date}
ユーザー名: ${record.clientName}

要約：
${record.summaryPoints.map((pt, idx) => `・${pt}`).join("\n")}

詳細メモ：
${record.notes || "特になし"}

文字起こし全文：
${record.transcript}`;

    navigator.clipboard.writeText(textToCopy);
    setCopiedId(record.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Format recording seconds
  const formatSeconds = (totalSecs: number) => {
    const mins = Math.floor(totalSecs / 60);
    const secs = totalSecs % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  // --- Calendar Date Management Functions ---
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const getDaysInMonth = (y: number, m: number) => new Date(y, m + 1, 0).getDate();
  const getFirstDayOfMonth = (y: number, m: number) => new Date(y, m, 1).getDay();

  const daysInMonth = getDaysInMonth(year, month);
  const firstDayIndex = getFirstDayOfMonth(year, month);

  const prevMonth = () => {
    setCurrentDate(new Date(year, month - 1, 1));
  };

  const nextMonth = () => {
    setCurrentDate(new Date(year, month + 1, 1));
  };

  const formattedSelectedDateJapanese = () => {
    const [y, m, d] = selectedCalendarDate.split("-");
    return `${y}年${parseInt(m)}月${parseInt(d)}日`;
  };

  // Fetch items corresponding to selected calendar date
  const selectedDateRecords = records.filter(r => r.date === selectedCalendarDate);
  const selectedDateEvents = events.filter(e => e.date === selectedCalendarDate);

  const handleDayClick = (dayNum: number) => {
    const dateStr = `${year}-${(month + 1).toString().padStart(2, "0")}-${dayNum.toString().padStart(2, "0")}`;
    setSelectedCalendarDate(dateStr);
  };

  // Create clean manual visit event on calendar
  const handleAddEvent = (e: FormEvent) => {
    e.preventDefault();
    if (!newEvent.title || !newEvent.clientName) return;

    const eventToCreate: VisitEvent = {
      id: "evt-man-" + Date.now(),
      date: newEvent.date,
      title: newEvent.title,
      clientName: newEvent.clientName,
      notes: newEvent.notes
    };

    setEvents(prev => [...prev, eventToCreate]);
    setShowAddEventModal(false);
    setNewEvent({
      title: "",
      clientName: "",
      date: selectedCalendarDate,
      notes: ""
    });
  };

  const deleteEvent = (id: string) => {
    setEvents(prev => prev.filter(ev => ev.id !== id));
  };

  // --- Search Filtering ---
  const filteredRecords = records.filter(rec => {
    const query = searchQuery.toLowerCase();
    return (
      rec.clientName.toLowerCase().includes(query) ||
      rec.transcript.toLowerCase().includes(query) ||
      rec.notes?.toLowerCase().includes(query) ||
      rec.summaryPoints.some(pt => pt.toLowerCase().includes(query))
    );
  });

  return (
    <div id="app" className="min-h-screen bg-[#F1F5F9] text-slate-800 font-sans flex flex-col antialiased">
      {/* Premium Elegant Header */}
      <header id="main-header" className="sticky top-0 bg-white border-b border-slate-200/80 z-40 shadow-xs px-4 py-3.5">
        <div className="max-w-md md:max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-gradient-to-tr from-indigo-600 to-indigo-550 rounded-xl p-2 text-white shadow-md shadow-indigo-100 flex items-center justify-center">
              <Mic className="h-5.5 w-5.5" />
            </div>
            <div>
              <h1 className="text-base md:text-lg font-bold text-slate-900 tracking-tight">営業ボイス議事録</h1>
              <p className="text-[10px] md:text-xs text-slate-500 font-medium">iPhone対応 録音 ＆ AI自動要約</p>
            </div>
          </div>
          
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl border border-slate-200">
            <button 
              id="btn-tab-memo"
              onClick={() => setActiveTab("memo")}
              className={`text-xs px-3 py-1.5 font-bold rounded-lg transition-all cursor-pointer ${
                activeTab === "memo" 
                  ? "bg-white text-indigo-700 shadow-xs" 
                  : "text-slate-600 hover:text-slate-950"
              }`}
            >
              ボイスメモ
            </button>
            <button 
              id="btn-tab-calendar"
              onClick={() => {
                setActiveTab("calendar");
                setSelectedCalendarDate("2026-06-11");
              }}
              className={`text-xs px-3 py-1.5 font-bold rounded-lg transition-all cursor-pointer ${
                activeTab === "calendar" 
                  ? "bg-white text-indigo-700 shadow-xs" 
                  : "text-slate-600 hover:text-slate-950"
              }`}
            >
              カレンダー
            </button>
            <button 
              id="btn-tab-list"
              onClick={() => setActiveTab("list")}
              className={`text-xs px-3 py-1.5 font-bold rounded-lg transition-all cursor-pointer ${
                activeTab === "list" 
                  ? "bg-white text-indigo-700 shadow-xs" 
                  : "text-slate-600 hover:text-slate-950"
              }`}
            >
              議事録一覧
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Area: Responsive Bento Grid dashboard container */}
      <main className="flex-1 max-w-md md:max-w-7xl w-full mx-auto p-4 md:p-6 pb-24 md:pb-12 justify-start flex flex-col gap-6">
        <div id="bento-dashboard" className="grid grid-cols-1 md:grid-cols-12 gap-6 w-full items-start">
          
          {/* ========================================================
              LEFT COLUMN: VISITING CALENDAR & STATS PROGRESS
              ======================================================== */}
          <div className="col-span-1 md:col-span-5 lg:col-span-4 flex flex-col gap-6 w-full">
            
          {/* Calendar & Selected Date Events */}
          <div id="calendar-section" className={`${activeTab === "calendar" ? "flex" : "hidden"} md:flex flex-col gap-4 w-full`}>
            
            {/* Calendar Grid Container */}
            <div className="bento-card p-5 bg-white">
              
              {/* Calendar Header with navigation handles */}
              <div className="flex items-center justify-between mb-4 px-1.5">
                <span className="text-sm font-bold text-slate-900 tracking-tight">
                  {year}年 {month + 1}月
                </span>
                
                <div className="flex items-center gap-1.5">
                  <button 
                    onClick={prevMonth}
                    className="p-1.5 rounded-lg hover:bg-slate-150 border border-slate-200 bg-slate-50 transition cursor-pointer"
                  >
                    <ChevronLeft className="w-4 h-4 text-slate-600" />
                  </button>
                  <button 
                    onClick={nextMonth}
                    className="p-1.5 rounded-lg hover:bg-slate-150 border border-slate-200 bg-slate-50 transition cursor-pointer"
                  >
                    <ChevronRight className="w-4 h-4 text-slate-600" />
                  </button>
                </div>
              </div>

              {/* Day headers */}
              <div className="grid grid-cols-7 gap-1 text-center text-[10px] font-extrabold text-slate-400 mb-2 tracking-wide">
                <div>日</div>
                <div>月</div>
                <div>火</div>
                <div>水</div>
                <div>木</div>
                <div>金</div>
                <div>土</div>
              </div>

              {/* Day cells */}
              <div className="grid grid-cols-7 gap-1">
                {/* Empty buffer cells for starting offset */}
                {Array.from({ length: firstDayIndex }).map((_, idx) => (
                  <div key={`empty-${idx}`} className="h-10" />
                ))}

                {/* Days of current month */}
                {Array.from({ length: daysInMonth }).map((_, idx) => {
                  const dayNum = idx + 1;
                  const dateStr = `${year}-${(month + 1).toString().padStart(2, "0")}-${dayNum.toString().padStart(2, "0")}`;
                  const isSelected = selectedCalendarDate === dateStr;
                  
                  // Check records and events on this date
                  const dayRecords = records.filter(r => r.date === dateStr);
                  const dayEvents = events.filter(e => e.date === dateStr);
                  const hasNegotiation = dayRecords.length > 0;
                  const hasEvent = dayEvents.length > 0;

                  return (
                    <button
                      key={`day-${dayNum}`}
                      onClick={() => handleDayClick(dayNum)}
                      className={`h-11 rounded-xl flex flex-col items-center justify-between p-1.5 transition-all text-xs font-bold relative cursor-pointer ${
                        isSelected 
                          ? "bg-indigo-600 text-white shadow-md shadow-indigo-100" 
                          : "hover:bg-slate-100 text-slate-800"
                      }`}
                    >
                      <span className="leading-none">{dayNum}</span>
                      
                      {/* Interactive indicator dots */}
                      <div className="flex gap-0.5 justify-center mt-0.5 w-full">
                        {hasNegotiation && (
                          <span className={`w-1.5 h-1.5 rounded-full ${isSelected ? "bg-white" : "bg-indigo-500"}`} />
                        )}
                        {hasEvent && (
                          <span className={`w-1.5 h-1.5 rounded-full ${isSelected ? "bg-amber-300" : "bg-amber-500"}`} />
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Quick instructions widget */}
              <div className="mt-4 pt-3.5 border-t border-slate-100 flex items-center justify-around text-[10px] text-slate-400 font-extrabold tracking-wide">
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-indigo-500" />
                  商談議事録
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                  訪問・予定
                </span>
              </div>
            </div>

            {/* Selected Date Details list */}
            <div className="bento-card p-5 bg-white space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div>
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">選択日の記録</span>
                  <p className="text-sm font-extrabold text-slate-900">{formattedSelectedDateJapanese()}</p>
                </div>

                <button
                  onClick={() => {
                    setNewEvent({ ...newEvent, date: selectedCalendarDate });
                    setShowAddEventModal(true);
                  }}
                  className="bg-indigo-50 hover:bg-indigo-100 text-indigo-700 py-1.5 px-3 rounded-xl text-xs font-bold flex items-center gap-1 transition cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  予定を追加
                </button>
              </div>

              {/* Negotiation Records matching date */}
              {selectedDateRecords.length === 0 && selectedDateEvents.length === 0 ? (
                <div className="py-8 text-center text-xs text-slate-400 leading-loose">
                  この日の予定、議事録はありません。<br />
                  ボイスメモを記録するか、「予定を追加」ボタンをタップしてください。
                </div>
              ) : (
                <div className="space-y-3">
                  
                  {/* Visited records */}
                  {selectedDateRecords.map(record => (
                    <div 
                      key={record.id} 
                      className="border border-indigo-100 bg-indigo-50/20 p-3.5 rounded-2xl flex flex-col gap-2 relative shadow-2xs"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] bg-indigo-100 text-indigo-800 font-bold px-2 py-0.5 rounded-full flex items-center gap-0.5">
                          <FileText className="w-3 h-3" />
                          音声議事録
                        </span>
                      </div>

                      <p className="text-xs font-bold text-slate-800">
                        <span className="text-slate-400 font-normal">ユーザー名: </span>
                        {record.clientName}
                      </p>
                      
                      <div className="bg-white p-2.5 rounded-xl border border-slate-100 space-y-1">
                        <span className="text-[10px] text-slate-400 font-bold block">要点要約：</span>
                        <ul className="text-xs text-slate-700 list-disc list-inside space-y-1">
                          {record.summaryPoints.map((p, i) => (
                            <li key={i}>{p}</li>
                          ))}
                        </ul>
                      </div>

                      <div className="flex gap-2 justify-end pt-1">
                        <button
                          onClick={() => copyToClipboard(record)}
                          className="text-slate-500 hover:text-indigo-600 font-bold text-[10px] flex items-center gap-1 px-2.5 py-1.5 bg-white rounded-lg border border-slate-200 cursor-pointer"
                        >
                          {copiedId === record.id ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-emerald-500" />
                              コピー完了!
                            </>
                          ) : (
                            <>
                              <Clipboard className="w-3.5 h-3.5" />
                              チャットへコピー
                            </>
                          )}
                        </button>
                        <button
                          onClick={() => {
                            setActiveTab("list");
                            setSearchQuery(record.clientName);
                            setExpandedRecordId(record.id);
                          }}
                          className="text-indigo-600 hover:text-indigo-800 font-bold text-[10px] flex items-center gap-1 px-2.5 py-1.5 bg-white rounded-lg border border-slate-200 cursor-pointer"
                        >
                          詳細を見る
                        </button>
                      </div>
                    </div>
                  ))}

                  {/* Registered events */}
                  {selectedDateEvents.map(event => (
                    <div 
                      key={event.id}
                      className="border border-amber-200 bg-amber-50/30 p-3.5 rounded-2xl flex flex-col gap-1 shadow-2xs relative"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-2 py-0.5 rounded-full flex items-center gap-0.5">
                          <CalendarIcon className="w-3 h-3" />
                          訪問予定
                        </span>
                        <button
                          onClick={() => deleteEvent(event.id)}
                          className="text-slate-400 hover:text-red-500 absolute top-3 right-3 cursor-pointer"
                          title="予定を削除"
                        >
                          ✕
                        </button>
                      </div>
                      
                      <p className="text-xs font-bold text-slate-900 mt-1">{event.title}</p>
                      
                      <div className="text-xs text-slate-600 space-y-1">
                        <p className="font-semibold flex items-center gap-1">
                          <Building2 className="w-3.5 h-3.5 text-slate-400" />
                          {event.clientName}
                        </p>
                        {event.notes && (
                          <p className="text-[11px] bg-white p-2 rounded-lg border border-slate-100 text-slate-500 mt-1 leading-normal">
                            メモ: {event.notes}
                          </p>
                        )}
                      </div>
                    </div>
                  ))}

                </div>
              )}
            </div>

            {/* Event Adding Prompt Dialog */}
            {showAddEventModal && (
              <div className="fixed inset-0 bg-black/45 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
                <div className="bg-white rounded-[24px] w-full max-w-sm p-6 space-y-4 shadow-xl border border-slate-100 animate-in fade-in zoom-in-95 duration-200">
                  <div className="border-b border-slate-100 pb-2.5">
                    <h3 className="text-sm font-bold text-slate-900">予定を登録する</h3>
                    <p className="text-[10px] text-slate-400 font-semibold">日付: {formattedSelectedDateJapanese()}</p>
                  </div>

                  <form onSubmit={handleAddEvent} className="space-y-3">
                    <div>
                      <label className="text-[10px] font-bold text-slate-450 block mb-1">件名 (例：デモ実演・フォローお礼)</label>
                      <input
                        type="text"
                        value={newEvent.title}
                        onChange={(e) => setNewEvent({ ...newEvent, title: e.target.value })}
                        className="w-full text-xs border border-slate-200 p-2.5 rounded-lg focus:border-indigo-500 outline-none"
                        placeholder="件名を入力"
                        required
                      />
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-slate-450 block mb-1">ユーザー名</label>
                      <input
                        type="text"
                        value={newEvent.clientName}
                        onChange={(e) => setNewEvent({ ...newEvent, clientName: e.target.value })}
                        className="w-full text-xs border border-slate-200 p-2.5 rounded-lg focus:border-indigo-500 outline-none"
                        placeholder="お名前、または会社名など"
                        required
                      />
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-slate-450 block mb-1">備考メモ (面談アジェンダなど)</label>
                      <textarea
                        value={newEvent.notes}
                        onChange={(e) => setNewEvent({ ...newEvent, notes: e.target.value })}
                        className="w-full text-xs border border-slate-200 p-2.5 rounded-lg h-16 focus:border-indigo-500 outline-none"
                        placeholder="持参資料などのメモ"
                      />
                    </div>

                    <div className="flex gap-2 pt-2">
                      <button
                        type="button"
                        onClick={() => setShowAddEventModal(false)}
                        className="flex-1 py-2 border border-slate-200 rounded-lg text-xs font-semibold hover:bg-slate-50 transition cursor-pointer"
                      >
                        キャンセル
                      </button>
                      <button
                        type="submit"
                        className="flex-1 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold shadow-xs transition cursor-pointer"
                      >
                        カレンダーへ追加
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            )}

          </div>

          {/* Dynamic Monthly Stats card (Desktop Only, synced to real state) */}
          <div id="stats-section" className="hidden md:flex bento-card p-6 flex-col justify-center text-center bg-white">
            <div className="text-3xl font-extrabold text-slate-800 mb-1">
              {records.length}
            </div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-widest leading-none mb-1">
              現在の登録商談数
            </p>
            <div className="mt-4 h-1.5 bg-slate-100 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-indigo-500 to-indigo-600 rounded-full transition-all duration-500" 
                style={{ width: `${Math.min(100, (records.length / 15) * 100)}%` }}
              />
            </div>
            <p className="mt-2 text-[10px] text-slate-450 font-bold">
              目標 15件 まで あと {Math.max(0, 15 - records.length)} 件 （進捗: {Math.round(Math.min(100, (records.length / 15) * 100))}%）
            </p>
          </div>

        </div>

        {/* ========================================================
            RIGHT COLUMN: RECORDER, DRAFT PREVIEW & MINUTES LOG
            ======================================================== */}
        <div className="col-span-1 md:col-span-7 lg:col-span-8 flex flex-col gap-6 w-full">
            
          {/* Voice Memo Recording Views */}
          <div id="memo-section" className={`${activeTab === "memo" ? "flex" : "hidden"} md:flex flex-col gap-4 w-full`}>
            
            {/* Engine selecting switch and settings overview */}
            <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-2xs flex flex-col sm:flex-row items-center justify-between gap-3">
              <span className="text-xs text-slate-700 font-bold flex items-center gap-2">
                <Settings className="w-4 h-4 text-slate-400" />
                音声変換AIエンジン:
              </span>
              <div className="flex gap-1.5 bg-slate-100 p-1 rounded-xl border border-slate-200">
                <button
                  id="engine-gemini"
                  type="button"
                  onClick={() => setEngine("gemini")}
                  className={`text-[11px] font-extrabold px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                    engine === "gemini" 
                      ? "bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-xs"
                      : "text-slate-600 hover:text-indigo-900 hover:bg-white/50"
                  }`}
                >
                  Gemini API (推奨)
                </button>
                <button
                  id="engine-whisper"
                  type="button"
                  onClick={() => setEngine("whisper")}
                  className={`text-[11px] font-extrabold px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                    engine === "whisper" 
                      ? "bg-indigo-600 text-white shadow-xs"
                      : "text-slate-600 hover:text-indigo-900 hover:bg-white/50"
                  }`}
                >
                  Whisper API
                </button>
              </div>
            </div>

            {engine === "whisper" && !process.env.OPENAI_API_KEY && (
              <div className="bg-amber-50 rounded-2xl p-4 border border-amber-200/80 text-[11px] text-amber-900 space-y-1.5 shadow-2xs">
                <p className="font-extrabold flex items-center gap-1.5 text-amber-800">
                  ⚠️ OpenAI APIキー未設定
                </p>
                <p className="leading-relaxed">
                  環境変数に <code className="bg-amber-100/80 px-1 py-0.5 rounded font-mono">OPENAI_API_KEY</code> が設定されていない場合、自動的に高精度な <strong>Gemini API 3.5-Flash 内蔵文字起こしモデル</strong> へフォールバックします（設定不要で無料ですぐ使えるのでそのままでOKです！）。
                </p>
              </div>
            )}

            {/* Interactive Recorder Canvas */}
            <div className="bento-card bg-gradient-to-br from-indigo-600 to-violet-850 text-white p-6 md:p-8 flex flex-col items-center justify-center text-center overflow-hidden relative min-h-[320px] border-none shadow-md">
              
              {/* Pulsing wave backdrop during active recording */}
              {isRecording && !isPaused && (
                <div className="absolute inset-0 bg-indigo-950/25 flex items-center justify-center -z-0 pointer-events-none">
                  <motion.div 
                    animate={{ scale: [1, 1.4, 1], opacity: [0.4, 0.1, 0.4] }}
                    transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
                    className="w-32 h-32 rounded-full bg-indigo-500/25"
                  />
                  <motion.div 
                    animate={{ scale: [1.2, 1.8, 1.2], opacity: [0.3, 0.05, 0.3] }}
                    transition={{ repeat: Infinity, duration: 2, delay: 0.5, ease: "easeInOut" }}
                    className="w-32 h-32 rounded-full bg-indigo-400/20"
                  />
                </div>
              )}

              <div className="relative z-10 w-full flex flex-col items-center">
                <span className="text-xs font-bold text-indigo-200 uppercase tracking-widest mb-1.5">
                  {isRecording ? (isPaused ? "録音一時停止中" : "音声録音中") : "ボイスメモ入力"}
                </span>

                {isRecording ? (
                  <div className="flex flex-col items-center gap-3 my-2 w-full">
                    {/* Live Duration Timer text */}
                    <span className="text-5xl font-mono font-extrabold text-white tracking-tight drop-shadow-sm select-none">
                      {formatSeconds(recordingDuration)}
                    </span>
                    <div className="flex flex-col items-center gap-2 w-full">
                      {isPaused ? (
                        <div className="flex items-center gap-1.5">
                          <span className="h-2 w-2 rounded-full bg-amber-400 animate-pulse" />
                          <span className="text-xs text-amber-200 font-bold">一時停止中 (録音を中断しています)</span>
                        </div>
                      ) : (
                        <div className="flex items-center gap-1.5">
                          <span className="h-2.5 w-2.5 rounded-full bg-red-400 animate-ping" />
                          <span className="text-xs text-indigo-50 font-bold">REC... マイクがお話し中の音声を拾っています</span>
                        </div>
                      )}
                      
                      {/* Animated wave bars matching aesthetic */}
                      <div className="flex items-end justify-center gap-1.5 h-10 mt-2 px-4 w-full max-w-xs">
                        {Array.from({ length: 16 }).map((_, i) => (
                          <div
                            key={i}
                            ref={(el) => {
                              barsRef.current[i] = el;
                            }}
                            className="bg-gradient-to-t from-indigo-300 via-white to-white w-2 pb-0 rounded-full"
                            style={{
                              height: "100%",
                              transform: "scaleY(0.08)",
                              transformOrigin: "bottom",
                              transition: "none",
                            }}
                          />
                        ))}
                      </div>

                      {/* Real-time speech transcription display widget */}
                      <div className="w-full max-w-md bg-black/25 backdrop-blur-xs rounded-xl p-3 border border-white/10 text-left mt-3">
                        <div className="flex items-center gap-1.5 mb-1.5">
                          <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                          <span className="text-[10px] font-extrabold text-indigo-200 tracking-wider uppercase">リアルタイム文字起こし (Live)</span>
                        </div>
                        <div 
                          ref={liveTranscriptScrollRef}
                          className="max-h-[85px] overflow-y-auto font-medium text-xs leading-relaxed text-slate-100 pr-1 select-text scrollbar-thin scrollbar-thumb-white/10 scrollbar-track-transparent"
                        >
                          {realtimeTranscript.trim() ? (
                            <span>{realtimeTranscript}</span>
                          ) : (
                            <span className="text-indigo-250 italic text-[11px]">発話が検知されると、リアルタイムでここに文字が表示されていきます...</span>
                          )}
                        </div>
                      </div>

                    </div>
                  </div>
                ) : (
                  <div className="my-4 text-indigo-100 space-y-2 max-w-sm">
                    <p className="text-lg font-bold text-white leading-snug">商談後にiPhoneに向かって話してください</p>
                    <p className="text-xs text-indigo-200 leading-relaxed font-medium">「担当は田中、相手は山田部長。来月新機能導入の合意をした...」など、自由に録音するだけで即座に構造化されます。</p>
                  </div>
                )}

                {/* Primary Large Micro Button Trigger / Pause controls */}
                <div className="my-4 flex flex-col items-center gap-3 w-full">
                  {!isRecording ? (
                    <>
                      <button
                        id="btn-rec-start"
                        onClick={startRecording}
                        disabled={isProcessing}
                        className="w-20 h-20 rounded-full bg-white text-indigo-600 hover:bg-slate-50 flex items-center justify-center shadow-xl hover:scale-105 active:scale-95 transition-all outline-hidden cursor-pointer"
                      >
                        <Mic className="w-8 h-8" />
                      </button>
                      
                      <div className="mt-2">
                        <label className="text-[11px] font-bold text-indigo-200 hover:text-white transition cursor-pointer flex items-center justify-center gap-1.5 bg-white/10 hover:bg-white/15 px-3 py-1.5 rounded-lg border border-white/20">
                          <Upload className="w-3.5 h-3.5" />
                          <span>オーディオファイルを読み込む</span>
                          <input
                            type="file"
                            accept="audio/*"
                            onChange={handleAudioFileChange}
                            className="hidden"
                          />
                        </label>
                      </div>
                    </>
                  ) : (
                    <div className="flex items-center justify-center gap-6 my-2 w-full">
                      {/* Pause / Resume Button */}
                      {isPaused ? (
                        <button
                          id="btn-rec-resume"
                          type="button"
                          onClick={resumeRecording}
                          className="flex flex-col items-center justify-center gap-1 text-[10px] font-extrabold text-amber-200 hover:text-white cursor-pointer select-none"
                        >
                          <div className="w-14 h-14 rounded-full bg-amber-500 hover:bg-amber-600 border-2 border-white flex items-center justify-center text-white shadow-lg transition-all transform hover:scale-105 active:scale-95">
                            <Play className="w-5 h-5 fill-white ml-0.5" />
                          </div>
                          <span>録音再開</span>
                        </button>
                      ) : (
                        <button
                          id="btn-rec-pause"
                          type="button"
                          onClick={pauseRecording}
                          className="flex flex-col items-center justify-center gap-1 text-[10px] font-extrabold text-indigo-200 hover:text-white cursor-pointer select-none"
                        >
                          <div className="w-14 h-14 rounded-full bg-white/10 hover:bg-white/20 border-2 border-white/40 flex items-center justify-center text-white shadow-lg transition-all transform hover:scale-105 active:scale-95">
                            <Pause className="w-5 h-5 text-white fill-white" />
                          </div>
                          <span>一時停止</span>
                        </button>
                      )}

                      {/* Stop and Analyze Button */}
                      <button
                        id="btn-rec-stop"
                        type="button"
                        onClick={stopRecording}
                        className="flex flex-col items-center justify-center gap-1.5 cursor-pointer select-none"
                      >
                        <div className="w-20 h-20 rounded-full bg-red-600 hover:bg-red-700 border-4 border-white flex items-center justify-center text-white shadow-xl hover:scale-105 active:scale-95 transition-all">
                          <Square className="w-6 h-6 text-white fill-white" />
                        </div>
                        <span className="text-xs font-bold text-white">録音終了して解析</span>
                      </button>
                    </div>
                  )}
                </div>

                {/* Cancel or Re-record row */}
                {isRecording && (
                  <button
                    id="btn-rec-cancel"
                    onClick={cancelRecording}
                    className="text-xs font-bold text-indigo-200 hover:text-white transition px-5 py-2.5 bg-white/10 hover:bg-white/15 rounded-full border border-white/20 mt-2 cursor-pointer"
                  >
                    録音をキャンセル
                  </button>
                )}
              </div>
            </div>

            {/* Error Displays */}
            {errorText && (
              <div className="bg-red-50 text-red-800 p-4 rounded-2xl border border-red-200 text-xs font-semibold space-y-1.5 leading-relaxed shadow-2xs">
                <span className="font-extrabold block text-sm">🚨 エラーが発生しました</span>
                <p>{errorText}</p>
                <button 
                  onClick={() => setErrorText(null)}
                  className="text-[10px] underline text-red-600 font-bold block pt-1.5 hover:text-red-800"
                >
                  閉じる
                </button>
              </div>
            )}

            {/* System Status and Spinner */}
            {isProcessing && (
              <div className="bg-white rounded-[24px] p-6 border border-indigo-100 flex flex-col items-center justify-center text-center space-y-3.5 shadow-xs">
                <div className="relative flex justify-center items-center">
                  <div className="animate-spin rounded-full h-11 w-11 border-4 border-slate-100 border-t-indigo-600" />
                  <Sparkles className="absolute text-indigo-500 h-5.5 w-5.5 animate-pulse" />
                </div>
                <div className="space-y-1.5">
                  <p className="text-xs font-bold text-slate-700 animate-pulse">{systemMessage}</p>
                  <p className="text-[10px] text-slate-400 leading-normal max-w-[280px] font-semibold">
                    ※音声の長さによっては、1分ほど処理に時間がかかる場合があります。アプリを閉じずにお待ちください。
                  </p>
                </div>
              </div>
            )}

          </div>

          {/* AI Response Preview Form: Editable before saving */}
          <AnimatePresence>
            {draftRecord && (
              <motion.div
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 15 }}
                className="bg-white rounded-[24.5px] border border-indigo-200/80 p-5 md:p-6 shadow-md space-y-4"
              >
                <div className="flex items-center justify-between border-b border-indigo-100 pb-3">
                  <div className="flex items-center gap-1.5">
                    <Sparkles className="w-5 h-5 text-indigo-500 animate-pulse" />
                    <h3 className="text-sm font-extrabold text-slate-900">AI解析プレビュー</h3>
                  </div>
                  <span className="text-[10px] uppercase tracking-wider font-extrabold text-indigo-600 bg-indigo-50 px-3 py-1 rounded-full">
                    登録前確認
                  </span>
                </div>

                <p className="text-xs text-slate-500 leading-relaxed font-semibold">
                  AIが情報を自動解析・抽出しました。必要に応じて直接修正して、一番下の「保存する」ボタンをタップしてください。
                </p>

                <div className="space-y-3">
                  {/* Input Dates */}
                  <div>
                    <label className="text-[10px] font-extrabold text-slate-450 block mb-1">記録日 (カレンダー連携)</label>
                    <input
                      type="date"
                      value={draftRecord.date}
                      onChange={(e) => setDraftRecord({ ...draftRecord, date: e.target.value })}
                      className="w-full text-xs bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-bold focus:border-indigo-550 focus:bg-white focus:ring-1 focus:ring-indigo-550 transition"
                      required
                    />
                  </div>

                  {/* Input Client Name */}
                  <div>
                    <label className="text-[10px] font-extrabold text-slate-450 block mb-1">ユーザー名（会社名・氏名など）</label>
                    <div className="relative">
                      <Building2 className="absolute left-2.5 top-3 h-4 w-4 text-slate-400" />
                      <input
                        type="text"
                        value={draftRecord.clientName}
                        onChange={(e) => setDraftRecord({ ...draftRecord, clientName: e.target.value })}
                        className="w-full text-xs bg-slate-50 border border-slate-200 pl-9 p-2.5 rounded-lg outline-none font-bold focus:border-indigo-550 focus:bg-white transition"
                        placeholder="お名前、または会社名（顧客情報）"
                      />
                    </div>
                  </div>

                  {/* Bullet Summaries as single text area */}
                  <div>
                    <label className="text-[10px] font-extrabold text-slate-450 block mb-1">要点・議事録の要約（箇条書き）</label>
                    <textarea
                      value={draftRecord.summaryPoints.join("\n")}
                      onChange={(e) => {
                        const lines = e.target.value.split("\n");
                        setDraftRecord({ ...draftRecord, summaryPoints: lines });
                      }}
                      className="w-full text-xs bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-bold h-36 resize-y leading-relaxed focus:border-indigo-550 focus:bg-white transition font-sans"
                      placeholder="・成果物について合意しました&#10;・来週木曜日に次回面談を行います"
                    />
                    <p className="text-[10px] text-slate-404 mt-1">※ 改行ごとに個別の箇条書き項目として区切られます。</p>
                  </div>�


                  {/* Editable Full Transcript */}
                  <div>
                    <label className="text-[10px] font-extrabold text-slate-450 block mb-1">全体の文字起こし全文</label>
                    <textarea
                      value={draftRecord.transcript}
                      onChange={(e) => setDraftRecord({ ...draftRecord, transcript: e.target.value })}
                      className="w-full text-xs bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-semibold h-24 resize-y leading-relaxed focus:border-indigo-550 focus:bg-white transition"
                    />
                  </div>

                  {/* Additional Notes */}
                  <div>
                    <label className="text-[10px] font-extrabold text-slate-450 block mb-1">補足メモ・次回アクション (自由記入)</label>
                    <textarea
                      value={draftRecord.notes}
                      onChange={(e) => setDraftRecord({ ...draftRecord, notes: e.target.value })}
                      className="w-full text-xs bg-slate-50 border border-slate-200 p-2.5 rounded-lg outline-none font-semibold h-16 resize-y focus:border-indigo-550 focus:bg-white transition"
                      placeholder="例：見積書を今週金曜に提出予定、フォローアップ必須など"
                    />
                  </div>
                </div>

                {/* Submission Row */}
                <div className="flex gap-2 pt-2.5 border-t border-slate-100">
                  <button
                    onClick={() => setDraftRecord(null)}
                    className="flex-1 py-2.5 border border-slate-250 text-slate-650 text-xs font-extrabold rounded-xl hover:bg-slate-50 transition cursor-pointer"
                  >
                    破棄する
                  </button>
                  <button
                    id="btn-save-record"
                    onClick={saveDraftToRecords}
                    className="flex-1 py-2.5 bg-gradient-to-r from-indigo-600 to-indigo-550 text-white text-xs font-bold rounded-xl shadow-md hover:from-indigo-700 hover:to-indigo-650 flex items-center justify-center gap-1 transition cursor-pointer"
                  >
                    議事録を保存する
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Comprehensive Minutes Feed tab container */}
          <div id="list-section" className={`${activeTab === "list" ? "flex" : "hidden"} md:flex flex-col gap-4 w-full`}>
            
            {/* Real Search bar filter widget */}
            <div className="relative">
              <Search className="absolute left-3 top-3.5 h-4 w-4 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="商談先、文字起こし、要約から検索..."
                className="w-full pl-9 pr-8 py-3 text-xs bg-white border border-slate-200 rounded-2xl outline-none focus:border-indigo-550 focus:ring-1 focus:ring-indigo-550 shadow-2xs font-bold"
              />
              {searchQuery && (
                <button 
                  onClick={() => setSearchQuery("")}
                  className="absolute right-3 top-3 text-xs font-extrabold text-slate-400 hover:text-slate-600 cursor-pointer p-0.5 select-none"
                >
                  ✕
                </button>
              )}
            </div>

            {/* List Feed */}
            {filteredRecords.length === 0 ? (
              <div className="bento-card p-10 text-center text-xs text-slate-400 bg-white leading-loose shadow-2xs">
                該当する議事録が見つかりません。<br />
                検索箇所を変えるか、新しくボイスメモを録音してください。
              </div>
            ) : (
              <div className="space-y-3.5">
                {filteredRecords.map(record => {
                  const isExpanded = expandedRecordId === record.id;
                  const isEditing = editingRecordId === record.id;
                  
                  return (
                    <div 
                      key={record.id}
                      className={`bg-white rounded-[20px] border transition-all ${
                        isExpanded ? "border-indigo-300 shadow-sm" : "border-slate-200/80 shadow-2xs"
                      }`}
                    >
                      {/* Tap header to toggle expanding */}
                      <button
                        onClick={() => setExpandedRecordId(isExpanded ? null : record.id)}
                        className="w-full text-left p-4.5 flex flex-col gap-1 outline-hidden cursor-pointer"
                      >
                        <div className="flex items-center justify-between text-[10px] text-slate-400 font-extrabold tracking-wide">
                          <span className="flex items-center gap-1.5 flex-1">
                            <Clock className="w-3 h-3 text-indigo-550" />
                            {record.date} 記録
                          </span>
                        </div>

                        <div className="flex items-start justify-between gap-2 mt-1.5 w-full">
                          <h4 className="text-xs md:text-sm font-extrabold text-slate-900 leading-snug">
                            <span className="text-slate-400 font-normal">ユーザー名:</span> {record.clientName}
                          </h4>
                          <div>
                            {isExpanded ? (
                              <ChevronUp className="w-4 h-4 text-slate-400 shrink-0" />
                            ) : (
                              <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                            )}
                          </div>
                        </div>

                        {/* Summary points preview collapsed */}
                        {!isExpanded && (
                          <div className="mt-2 text-xs text-slate-500 line-clamp-1 truncate font-semibold flex items-center gap-1">
                            <span className="text-indigo-500 font-extrabold">•</span> 
                            {record.summaryPoints[0]}
                          </div>
                        )}
                      </button>

                      {/* Extended Details */}
                      {isExpanded && (
                        <div className="px-4.5 pb-4.5 border-t border-slate-100 pt-4.5 space-y-4">
                          
                          {/* List of bullet points summary inside a single memo text field */}
                          <div className="space-y-1.5">
                            <span className="text-[11px] text-slate-450 font-extrabold block">
                              💡 商談要約（箇条書き）:
                            </span>
                            {isEditing ? (
                              <textarea
                                value={record.summaryPoints.map(pt => pt.startsWith("・") ? pt : `・${pt}`).join("\n")}
                                onChange={(e) => {
                                  const lines = e.target.value.split("\n").map(l => l.trim() ? l.replace(/^・/, "").trim() : "");
                                  const updated = records.map(r => r.id === record.id ? { ...r, summaryPoints: lines.filter(Boolean) } : r);
                                  setRecords(updated);
                                }}
                                className="w-full text-xs font-bold border border-indigo-200 rounded-lg p-2.5 h-28 focus:outline-hidden focus:border-indigo-650 focus:ring-1 focus:ring-indigo-650"
                              />
                            ) : (
                              <div className="text-xs text-slate-700 bg-white border border-slate-200/50 p-3 rounded-xl leading-relaxed whitespace-pre-wrap font-semibold">
                                {record.summaryPoints.map(pt => pt.startsWith("・") ? pt : `・${pt}`).join("\n")}
                              </div>
                            )}
                          </div>

                          {/* Editable transcription detailed box */}
                          <div className="space-y-1.5">
                            <span className="text-[11px] text-slate-450 font-extrabold block">
                              📝 文字起こし全文:
                            </span>
                            {isEditing ? (
                              <textarea
                                value={record.transcript}
                                onChange={(e) => {
                                  const updated = records.map(r => r.id === record.id ? { ...r, transcript: e.target.value } : r);
                                  setRecords(updated);
                                }}
                                className="w-full text-xs font-bold border border-indigo-200 rounded-lg p-2.5 h-28 focus:outline-hidden focus:border-indigo-650 focus:ring-1 focus:ring-indigo-650"
                              />
                            ) : (
                              <p className="text-xs text-slate-650 bg-white border border-slate-200/50 p-3 rounded-xl leading-relaxed whitespace-pre-wrap font-semibold">
                                {record.transcript}
                              </p>
                            )}
                          </div>

                          {/* Editable notes */}
                          { (record.notes || isEditing) && (
                            <div className="space-y-1.5">
                              <span className="text-[11px] text-slate-450 font-extrabold block">
                                📌 補足メモ・ToDo:
                              </span>
                              {isEditing ? (
                                <textarea
                                  value={record.notes || ""}
                                  onChange={(e) => {
                                    const updated = records.map(r => r.id === record.id ? { ...r, notes: e.target.value } : r);
                                    setRecords(updated);
                                  }}
                                />
                              ) : (
                                <p className="text-xs text-slate-550 italic bg-amber-50/20 border border-amber-200/50 p-3 rounded-xl leading-normal font-semibold">
                                  {record.notes}
                                </p>
                              )}
                            </div>
                          )}

                          {/* Actions Bar inside card */}
                          <div className="flex gap-1.5 justify-between items-center pt-3 border-t border-slate-100">
                            
                            {confirmingDeleteId === record.id ? (
                              <div className="flex items-center gap-2 bg-red-50 p-1.5 rounded-lg border border-red-100">
                                <span className="text-red-700 text-[10px] font-extrabold">本当に削除しますか？</span>
                                <button
                                  onClick={() => deleteRecord(record.id)}
                                  className="bg-red-600 hover:bg-red-700 text-white font-extrabold text-[10px] px-2 py-1 rounded-md cursor-pointer transition"
                                >
                                  はい、削除する
                                </button>
                                <button
                                  onClick={() => setConfirmingDeleteId(null)}
                                  className="bg-slate-200 hover:bg-slate-300 text-slate-700 font-extrabold text-[10px] px-2 py-1 rounded-md cursor-pointer transition"
                                >
                                  戻る
                                </button>
                              </div>
                            ) : (
                              <button
                                onClick={() => setConfirmingDeleteId(record.id)}
                                className="text-red-500 hover:text-red-700 font-bold text-[11px] flex items-center gap-1.5 p-1.5 hover:bg-red-50 rounded-lg cursor-pointer transition select-none"
                                title="削除"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                                議事録削除
                              </button>
                            )}

                            <div className="flex gap-1.5">
                              {/* Edit Trigger */}
                              <button
                                onClick={() => setEditingRecordId(isEditing ? null : record.id)}
                                className="text-slate-600 hover:text-slate-900 font-semibold text-[11px] flex items-center gap-1 py-1.5 px-3 bg-slate-100 rounded-xl"
                              >
                                <Edit3 className="w-3 h-3 text-slate-500" />
                                {isEditing ? "保存" : "編集"}
                              </button>

                              {/* Copy to Slack / business chat tool button */}
                              <button
                                onClick={() => copyToClipboard(record)}
                                className="bg-gradient-to-tr from-indigo-600 to-indigo-500 hover:from-indigo-700 hover:to-indigo-600 text-white font-bold text-[11px] flex items-center gap-1 py-1.5 px-3 rounded-xl shadow-xs"
                              >
                                {copiedId === record.id ? (
                                  <>
                                    <Check className="w-3.5 h-3.5 text-emerald-300" />
                                    コピー完了!
                                  </>
                                ) : (
                                  <>
                                    <Clipboard className="w-3.5 h-3.5" />
                                    チャットへコピー
                                  </>
                                )}
                              </button>
                            </div>

                          </div>

                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}

          </div>

        </div>

      </div>
    </main>

      {/* iPhone Persistent Navigation Bar */}
      <footer className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 py-2.5 z-40 shadow-xl px-4">
        <div className="max-w-md mx-auto flex justify-around">
          
          {/* Tab Button 1: Recorder */}
          <button
            onClick={() => setActiveTab("memo")}
            className={`flex flex-col items-center gap-1 text-[10px] font-bold ${
              activeTab === "memo" ? "text-indigo-600" : "text-slate-400 hover:text-slate-600"
            }`}
          >
            <Mic className={`h-5 w-5 ${activeTab === "memo" ? "stroke-[2.5px]" : "stroke-[1.8px]"}`} />
            <span>音声入力</span>
          </button>

          {/* Tab Button 2: Calendar */}
          <button
            onClick={() => {
              setActiveTab("calendar");
              setSelectedCalendarDate("2026-06-11");
            }}
            className={`flex flex-col items-center gap-1 text-[10px] font-bold ${
              activeTab === "calendar" ? "text-indigo-600" : "text-slate-400 hover:text-slate-600"
            }`}
          >
            <CalendarIcon className={`h-5 w-5 ${activeTab === "calendar" ? "stroke-[2.5px]" : "stroke-[1.8px]"}`} />
            <span>カレンダー</span>
          </button>

          {/* Tab Button 3: List */}
          <button
            onClick={() => setActiveTab("list")}
            className={`flex flex-col items-center gap-1 text-[10px] font-bold ${
              activeTab === "list" ? "text-indigo-600" : "text-slate-400 hover:text-slate-600"
            }`}
          >
            <FileText className={`h-5 w-5 ${activeTab === "list" ? "stroke-[2.5px]" : "stroke-[1.8px]"}`} />
            <span>議事録一覧</span>
          </button>

        </div>
      </footer>
    </div>
  );
}
