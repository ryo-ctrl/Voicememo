export interface NegotiationRecord {
  id: string;
  date: string; // YYYY-MM-DD
  userName: string;
  clientName: string;
  transcript: string;
  summaryPoints: string[];
  notes?: string;
  createdAt: string;
}

export interface VisitEvent {
  id: string;
  date: string; // YYYY-MM-DD
  title: string;
  clientName: string;
  notes?: string;
}

export interface TranscribeResponse {
  transcription: string;
  userName: string;
  clientName: string;
  summaryPoints: string[];
}
